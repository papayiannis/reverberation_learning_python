This is a copy of the files from ACE Challenge Corpus [1], which are used for this work.

The corpus is available under 'Creative Commons Attribution-NoDerivatives 4.0 International Public License'. A copy of the license is included in this folder.

[1] J. Eaton; N. D. Gaubitch; A. H. Moore; P. A. Naylor, "Estimation of room acoustic parameters: The ACE Challenge," in IEEE/ACM Transactions on Audio, Speech, and Language Processing, vol. 24, no.10, pp.1681-1693, Oct. 2016. 

http://www.ee.ic.ac.uk/naylor/ACEweb/index.html
